Cross-Browser Rich Text Editor
==============================

The original Cross-Browser Rich Text Editor (RTE) is based on the designMode() functionality introduced in Internet Explorer 5, and implemented in Mozilla 1.3+ using the Mozilla Rich Text Editing API.

Project Home: http://www.kevinroth.com/rte
